chrome.devtools.panels.create(
	"Auxilio", 
	"img/icon16.png", 
	"index.html",
	function() {
		
	}
);